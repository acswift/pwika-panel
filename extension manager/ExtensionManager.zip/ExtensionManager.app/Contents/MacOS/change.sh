#!/bin/bash
USER=`whoami`;
sudo chown -R $USER "$1"